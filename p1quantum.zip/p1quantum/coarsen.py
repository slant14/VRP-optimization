"""Spatio-temporal coarsening for CVRPTW with switchable window-propagation.

Rules for the window/duration of a merged super-node (order i -> j fixed):

  conservative (paper 3):  E = max(e_i, e_j), L = min(l_i, l_j)
                           admissible iff windows OVERLAP and the separate
                           feasibility predicate e_i + s_i + tau <= l_j holds.
                           Sound (with the predicate) but INCOMPLETE: rejects
                           disjoint-but-sequenceable windows.

  relaxed:                 E = min(e_i, e_j - s_i - tau),
                           L = max(l_i, l_j - s_i - tau).
                           Complete but UNSOUND: can admit merges with no
                           feasible internal schedule -> TW violations appear
                           only after inflation.

  exact (this work):       E = e_i, L = min(l_i, l_j - s_i - tau),
                           admissible iff E <= L. Sound AND complete: admits
                           a merge iff a feasible internal schedule exists.
                           Duration S = s_i + tau + s_j + max(0, e_j - E - s_i - tau)
                           upper-bounds true duration for every start in
                           [E, L], so coarse-feasible routes inflate to
                           feasible original routes with NO repair.

Every super-node carries (E, L, S, demand) -- the same signature as a
customer -- so all rules compose across multiple coarsening levels.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from instances import Instance


@dataclass
class SNode:
    members: list      # ordered original indices (internal service order)
    xy: np.ndarray     # centroid, used ONLY for merge scoring
    demand: float
    S: float           # duration: total internal service + travel (+ wait ub)
    E: float           # earliest service start
    L: float           # latest arrival admitting a feasible schedule

    @property
    def head(self):
        return self.members[0]

    @property
    def tail(self):
        return self.members[-1]


def _merge(a: SNode, b: SNode, tau: float, rule: str):
    """Return merged SNode for order a -> b, or None if inadmissible."""
    if rule == "exact":
        E = a.E
        L = min(a.L, b.L - a.S - tau)
        if E > L + 1e-9:
            return None
        wait = max(0.0, b.E - (E + a.S + tau))
        S = a.S + tau + wait + b.S
    elif rule == "conservative":
        # separate feasibility predicate + window intersection
        if a.E + a.S + tau > b.L + 1e-9:
            return None
        E, L = max(a.E, b.E), min(a.L, b.L)
        if E > L + 1e-9:
            return None
        S = a.S + tau + b.S
    elif rule == "relaxed":
        if a.E + a.S + tau > b.L + 1e-9:
            return None
        E = min(a.E, b.E - a.S - tau)
        L = max(a.L, b.L - a.S - tau)
        E = max(E, 0.0)
        S = a.S + tau + b.S
    else:
        raise ValueError(rule)
    return SNode(a.members + b.members, (a.xy + b.xy) / 2,
                 a.demand + b.demand, S, E, L)


@dataclass
class Coarsened:
    inst: Instance
    nodes: list                     # nodes[0] = depot SNode
    tau: np.ndarray

    @property
    def m(self):
        return len(self.nodes)


def coarsen(inst: Instance, P: float = 0.4, rule: str = "exact",
            alpha: float = 0.5, beta: float = 0.5,
            radius: float = 0.3, max_levels: int = 50) -> Coarsened:
    """Iterative pairwise merging until <= P * N customers remain.

    Merge score is the scale-free spatio-temporal metric
        D_ij = alpha * tau_ij / span + beta * |mid_i - mid_j| / horizon
    (midpoints of current windows). Direction of each admissible pair is the
    one with larger residual slack L - E.
    """
    nodes = [SNode([i], inst.xy[i].copy(), float(inst.demand[i]),
                   float(inst.service[i]), float(inst.ready[i]),
                   float(inst.due[i])) for i in range(inst.n_customers + 1)]
    n0 = len(nodes) - 1
    span = max(np.ptp(inst.xy[:, 0]), np.ptp(inst.xy[:, 1])) or 1.0
    horizon = float(inst.due[0]) or 1.0

    dm = inst.dist
    for _ in range(max_levels):
        if len(nodes) - 1 <= P * n0:
            break
        m = len(nodes)
        cand = []
        for i in range(1, m):
            for j in range(i + 1, m):
                # centroid distance ONLY for scoring; feasibility and cost
                # use exact boundary (tail -> head) distances below
                t = float(np.linalg.norm(nodes[i].xy - nodes[j].xy))
                dT = abs((nodes[i].E + nodes[i].L) / 2
                         - (nodes[j].E + nodes[j].L) / 2)
                D = alpha * t / span + beta * dT / horizon
                if D <= radius:
                    cand.append((D, i, j))
        cand.sort()
        used, new_nodes, kill = set(), [], set()
        remaining = m - 1
        for D, i, j in cand:
            if remaining <= P * n0:
                break
            if i in used or j in used:
                continue
            # exact connecting travel for each direction
            mij = _merge(nodes[i], nodes[j],
                         float(dm[nodes[i].tail, nodes[j].head]), rule)
            mji = _merge(nodes[j], nodes[i],
                         float(dm[nodes[j].tail, nodes[i].head]), rule)
            if mij is not None and mji is not None:
                pick = mij if (mij.L - mij.E) >= (mji.L - mji.E) else mji
            else:
                pick = mij or mji
            if pick is None:
                continue
            new_nodes.append(pick)
            used.update((i, j))
            kill.update((i, j))
            remaining -= 1
        if not new_nodes:
            break
        nodes = [nd for k, nd in enumerate(nodes) if k not in kill] + new_nodes

    m = len(nodes)
    tau = np.zeros((m, m))
    for i in range(m):
        for j in range(m):
            if i != j:
                # exact boundary travel: leave tail of i, arrive head of j
                tau[i, j] = float(dm[nodes[i].tail, nodes[j].head])
    return Coarsened(inst, nodes, tau)


def as_view(inst: Instance) -> Coarsened:
    """Identity view: the uncoarsened instance in SNode form (baseline)."""
    nodes = [SNode([i], inst.xy[i].copy(), float(inst.demand[i]),
                   float(inst.service[i]), float(inst.ready[i]),
                   float(inst.due[i])) for i in range(inst.n_customers + 1)]
    return Coarsened(inst, nodes, inst.dist.copy())


def inflate(routes_super: list, co: Coarsened) -> list:
    return [[orig for s in r for orig in co.nodes[s].members]
            for r in routes_super]


def evaluate(inst: Instance, routes: list):
    dist = tw_viol = cap_viol = 0.0
    for r in routes:
        if not r:
            continue
        if sum(inst.demand[c] for c in r) > inst.capacity + 1e-9:
            cap_viol += 1
        t, prev = 0.0, 0
        for c in r:
            t += inst.dist[prev, c]
            dist += inst.dist[prev, c]
            t = max(t, inst.ready[c])
            if t > inst.due[c] + 1e-9:
                tw_viol += 1
            t += inst.service[c]
            prev = c
        dist += inst.dist[prev, 0]
    return {"distance": round(dist, 1), "tw_viol": int(tw_viol),
            "cap_viol": int(cap_viol),
            "vehicles": sum(1 for r in routes if r)}
