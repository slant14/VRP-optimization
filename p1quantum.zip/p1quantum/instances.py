"""Solomon CVRPTW instance handling.

Parses the standard Solomon .txt format and can synthesize small
Solomon-like instances for quick experiments without downloads.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

import numpy as np


@dataclass
class Instance:
    name: str
    n_vehicles: int
    capacity: float
    # index 0 is the depot
    xy: np.ndarray          # (n+1, 2)
    demand: np.ndarray      # (n+1,)
    ready: np.ndarray       # (n+1,)  e_i
    due: np.ndarray         # (n+1,)  l_i
    service: np.ndarray     # (n+1,)  s_i
    dist: np.ndarray = field(default=None)  # (n+1, n+1) Euclidean

    def __post_init__(self):
        d = self.xy[:, None, :] - self.xy[None, :, :]
        self.dist = np.sqrt((d ** 2).sum(-1))

    @property
    def n_customers(self) -> int:
        return len(self.demand) - 1


def parse_solomon(path: str) -> Instance:
    with open(path) as f:
        text = f.read()
    lines = [l for l in text.splitlines() if l.strip()]
    name = lines[0].strip()
    nums = []
    for l in lines:
        toks = re.findall(r"-?\d+\.?\d*", l)
        if len(toks) == 2 and "VEHICLE" not in l and "CUST" not in l.upper():
            nums.append((int(float(toks[0])), float(toks[1])))
    n_vehicles, capacity = nums[0]
    rows = []
    for l in lines:
        toks = re.findall(r"-?\d+\.?\d*", l)
        if len(toks) == 7:
            rows.append([float(t) for t in toks])
    rows.sort(key=lambda r: r[0])
    arr = np.array(rows)
    return Instance(
        name=name, n_vehicles=n_vehicles, capacity=capacity,
        xy=arr[:, 1:3], demand=arr[:, 3], ready=arr[:, 4],
        due=arr[:, 5], service=arr[:, 6],
    )


def parse_solomon_csv(path: str, n_vehicles: int = 25,
                      capacity: float = 200.0) -> Instance:
    """CSV format used in the paper's repo (mkingmking/graph-coarsening):
    CUST NO.,XCOORD.,YCOORD.,DEMAND,READY TIME,DUE DATE,SERVICE TIME
    Row with CUST NO.=1 is the depot."""
    import csv
    rows = []
    with open(path) as f:
        first = f.readline()
        if first.upper().startswith("CAPACITY"):
            capacity = float(first.split(",")[1])
        else:
            f.seek(0)
        for r in csv.DictReader(f):
            rows.append([float(r[k]) for k in
                         ("CUST NO.", "XCOORD.", "YCOORD.", "DEMAND",
                          "READY TIME", "DUE DATE", "SERVICE TIME")])
    rows.sort(key=lambda r: r[0])
    arr = np.array(rows)
    return Instance(
        name=path.rsplit("/", 1)[-1], n_vehicles=n_vehicles,
        capacity=capacity, xy=arr[:, 1:3], demand=arr[:, 3],
        ready=arr[:, 4], due=arr[:, 5], service=arr[:, 6],
    )


def synthetic(n: int = 30, n_vehicles: int = 4, capacity: float = 200.0,
              horizon: float = 1000.0, seed: int = 0,
              clustered: bool = True) -> Instance:
    """Solomon-like synthetic instance (clustered coords, feasible windows)."""
    rng = np.random.default_rng(seed)
    if clustered:
        k = max(2, n // 8)
        centers = rng.uniform(10, 90, size=(k, 2))
        idx = rng.integers(0, k, size=n)
        xy = centers[idx] + rng.normal(0, 5, size=(n, 2))
    else:
        xy = rng.uniform(0, 100, size=(n, 2))
    depot = np.array([[50.0, 50.0]])
    xy = np.vstack([depot, xy])
    demand = np.concatenate([[0], rng.integers(5, 30, size=n)])
    service = np.concatenate([[0], np.full(n, 10.0)])
    # feasible-by-construction windows: center at (depot travel time * u), width varies
    d0 = np.sqrt(((xy - depot) ** 2).sum(-1))
    center = d0 + rng.uniform(0.1, 0.7, size=n + 1) * (horizon - 2 * d0.max())
    width = rng.uniform(30, 120, size=n + 1)
    ready = np.clip(center - width, 0, None)
    due = np.minimum(center + width, horizon)
    ready[0], due[0] = 0.0, horizon
    return Instance("synthetic", n_vehicles, capacity, xy, demand,
                    ready, due, service)
