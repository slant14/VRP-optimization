"""Paper 3's classical solvers, operating on a Coarsened view (which may be
the identity view = original instance). Both are time-window- and
capacity-aware, using each SNode's (E, L, S, demand).

Feasibility on the coarse level uses arrival-time simulation:
    arrive a -> start max(a, E) -> must have a <= L -> leave at start + S.
Under the 'exact' propagation rule this implies feasibility of the inflated
original route (see coarsen.py docstring); under 'relaxed' it does not.
"""
from __future__ import annotations

from coarsen import Coarsened


def _route_ok(co: Coarsened, route: list) -> bool:
    if sum(co.nodes[s].demand for s in route) > co.inst.capacity + 1e-9:
        return False
    t, prev = 0.0, 0
    for s in route:
        a = t + co.tau[prev, s]
        nd = co.nodes[s]
        if a > nd.L + 1e-9:
            return False
        t = max(a, nd.E) + nd.S
        prev = s
    return t + co.tau[prev, 0] <= co.nodes[0].L + 1e-9


def greedy(co: Coarsened) -> list:
    unserved = set(range(1, co.m))
    routes = []
    while unserved:
        route, load, t, prev = [], 0.0, 0.0, 0
        while True:
            cands = []
            for s in unserved:
                nd = co.nodes[s]
                a = t + co.tau[prev, s]
                if a <= nd.L + 1e-9 and load + nd.demand <= co.inst.capacity:
                    cands.append((co.tau[prev, s], s, a))
            if not cands:
                break
            _, s, a = min(cands)
            nd = co.nodes[s]
            route.append(s)
            unserved.discard(s)
            load += nd.demand
            t = max(a, nd.E) + nd.S
            prev = s
        if not route:
            route = [unserved.pop()]
        routes.append(route)
    return routes


def savings(co: Coarsened) -> list:
    """Clarke-Wright parallel savings with feasibility-checked merges."""
    routes = {s: [s] for s in range(1, co.m)}
    owner = {s: s for s in range(1, co.m)}
    sav = []
    for i in range(1, co.m):
        for j in range(1, co.m):
            if i != j:
                sav.append((co.tau[0, i] + co.tau[0, j] - co.tau[i, j], i, j))
    sav.sort(reverse=True)
    for sv, i, j in sav:
        if sv <= 0:
            break
        ri, rj = owner[i], owner[j]
        if ri == rj:
            continue
        # merge only end-of-route(i) with start-of-route(j)
        if routes[ri][-1] != i or routes[rj][0] != j:
            continue
        cand = routes[ri] + routes[rj]
        if _route_ok(co, cand):
            routes[ri] = cand
            for s in routes[rj]:
                owner[s] = ri
            del routes[rj]
    return list(routes.values())
