"""Experiment C -- encoding ablation at equal sampling budget.

For open TSPs of size n = 6..14 drawn from C101 customer subsets, compare
one-hot vs domain-wall on: variables, valid-sample fraction, best decoded
tour length (relative to the best over both encodings), sampling time.
Identical num_reads / num_sweeps. Writes results_expC.csv.
"""
from __future__ import annotations

import csv

import numpy as np

import qubo
from instances import parse_solomon_csv
from samplers import feasible_fraction, sample_bqm

READS, SWEEPS = 500, 2000


def tour_len(tau, order):
    t = tau[0, order[0]]
    for a, b in zip(order, order[1:]):
        t += tau[a, b]
    return t + tau[order[-1], 0]


def main():
    inst = parse_solomon_csv("C101.csv")
    rng = np.random.default_rng(1)
    rows = []
    hdr = (f"{'n':>3} {'trial':>5} {'encoding':<11} {'vars':>5} "
           f"{'valid%':>7} {'best_len':>9} {'t_s':>5}")
    print(hdr)
    print("-" * len(hdr))
    for n in (6, 8, 10, 12, 14):
        for trial in range(3):
            nodes = list(rng.choice(range(1, 101), size=n, replace=False))
            res = {}
            for enc in ("onehot", "domainwall"):
                bqm, mt = qubo.tsp_bqm(nodes, inst.dist, encoding=enc)
                ss, t = sample_bqm(bqm, num_reads=READS, sweeps=SWEEPS,
                                   seed=trial)
                vfrac = feasible_fraction(ss, qubo.decode_tsp, mt)
                best = float("inf")
                for s in ss.samples():
                    order = qubo.decode_tsp(dict(s), mt)
                    if order is not None:
                        best = min(best, tour_len(inst.dist, order))
                res[enc] = (bqm.num_variables, vfrac, best, t)
            for enc in ("onehot", "domainwall"):
                v, f, b, t = res[enc]
                bl = "inf" if b == float("inf") else f"{b:.1f}"
                print(f"{n:>3} {trial:>5} {enc:<11} {v:>5} "
                      f"{100 * f:>6.1f} {bl:>9} {t:>5.1f}")
                rows.append([n, trial, enc, v, round(100 * f, 1), bl,
                             round(t, 1)])
    with open("results_expC.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["n", "trial", "encoding", "vars", "valid_pct",
                    "best_len", "t_s"])
        w.writerows(rows)
    print("\nwrote results_expC.csv")


if __name__ == "__main__":
    main()
