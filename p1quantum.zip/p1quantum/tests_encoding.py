"""Correctness tests run before any experiment.

1. Domain-wall BQM energy equals one-hot BQM energy on every valid tour
   (exact affine transform).
2. Both encodings' ground states over all valid tours coincide with the
   brute-force optimal open tour.
"""
import itertools

import numpy as np

import qubo


def _tour_len(tau, order):
    t = tau[0, order[0]]
    for a, b in zip(order, order[1:]):
        t += tau[a, b]
    return t + tau[order[-1], 0]


def _encode_onehot(order, nodes, n):
    return {f"x_{p}_{nodes.index(c)}": 1 for p, c in enumerate(order)} | {
        f"x_{p}_{ci}": 0 for p in range(n) for ci in range(n)
        if nodes[order.index(nodes[ci])] is None} if False else {
        **{f"x_{p}_{ci}": (1 if nodes[ci] == order[p] else 0)
           for p in range(n) for ci in range(n)}}


def _encode_dw(order, nodes, n):
    s = {}
    for p, c in enumerate(order):
        ci = nodes.index(c)
        for k in range(1, n):
            s[f"z_{p}_{k}"] = 1 if k <= ci else 0
    return s


def main():
    rng = np.random.default_rng(7)
    n = 5
    xy = rng.uniform(0, 100, (n + 1, 2))
    tau = np.sqrt(((xy[:, None] - xy[None]) ** 2).sum(-1))
    nodes = list(range(1, n + 1))
    b1, m1 = qubo.tsp_bqm(nodes, tau, encoding="onehot")
    b2, m2 = qubo.tsp_bqm(nodes, tau, encoding="domainwall")
    print(f"vars: onehot={b1.num_variables} domainwall={b2.num_variables}")

    worst = 0.0
    best_len, best_perm = None, None
    for perm in itertools.permutations(nodes):
        L = _tour_len(tau, list(perm))
        if best_len is None or L < best_len:
            best_len, best_perm = L, list(perm)
        e1 = b1.energy(_encode_onehot(list(perm), nodes, n))
        e2 = b2.energy(_encode_dw(list(perm), nodes, n))
        worst = max(worst, abs(e1 - e2), abs(e1 - L))
        assert qubo.decode_tsp(_encode_onehot(list(perm), nodes, n), m1) \
            == list(perm)
        assert qubo.decode_tsp(_encode_dw(list(perm), nodes, n), m2) \
            == list(perm)
    print(f"max |E_onehot - E_domainwall| over all {n}! valid tours: "
          f"{worst:.2e}")
    print(f"E(valid tour) == tour length: OK; decoders: OK; "
          f"optimum={best_len:.2f} at {best_perm}")
    assert worst < 1e-8
    print("ALL ENCODING TESTS PASSED")


if __name__ == "__main__":
    main()
