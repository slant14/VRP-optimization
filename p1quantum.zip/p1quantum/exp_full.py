"""Experiment B -- full-scale hybrid pipeline (N = 100 Solomon instances).

    exact-window coarsening (P)                    [classical, round-2 fix]
      -> conflict-aware assignment BQM             [sampled]
      -> per-cluster domain-wall TSP BQMs
         with TW conflict-pair penalties           [sampled]
      -> inflation, NO repair                      [classical]
      -> evaluation on the ORIGINAL instance

Sampler: dwave.samplers.SimulatedAnnealingSampler. For reference, the FQS
formulation of the same instances would need M * N^2 = O(10^5) variables --
unbuildable/unsamplable in practice, which is exactly paper 1's reported
limitation.

Writes results_expB.csv.
"""
from __future__ import annotations

import csv
import sys
import time

import numpy as np

import qubo
from coarsen import as_view, coarsen, evaluate, inflate
from instances import parse_solomon_csv
from samplers import feasible_fraction, sample_bqm
from solvers import savings

READS, SWEEPS, TOPK = 300, 2000, 5


def run_instance(path, P=0.4, seed=42):
    inst = parse_solomon_csv(path)
    t0 = time.time()
    co = coarsen(inst, P=P, rule="exact")
    m = co.m - 1
    E = np.array([nd.E for nd in co.nodes])
    L = np.array([nd.L for nd in co.nodes])
    S = np.array([nd.S for nd in co.nodes])
    dem = np.array([nd.demand for nd in co.nodes])

    mid = (E + L) / 2
    D = 0.5 * co.tau + 0.5 * np.abs(mid[:, None] - mid[None, :]) \
        * (co.tau.max() / max(inst.due[0], 1))

    # fleet size from a TW-aware coarse-level savings run (capacity LB is
    # wildly wrong for tight-window type-1 instances), and use its
    # clustering as a warm-start member of the assignment pool
    cw_routes = savings(co)
    M = len(cw_routes) + 1

    conflicts = qubo.tw_conflicts(list(range(1, co.m)), E, L, S, co.tau)
    mutual = {(i, j) for (i, j) in conflicts if (j, i) in conflicts}

    bqm_a, ma = qubo.assignment_bqm(D, co.tau[0], dem, M, inst.capacity,
                                    mutual_conflicts=mutual)
    ss, t_a = sample_bqm(bqm_a, num_reads=READS, sweeps=SWEEPS, seed=seed)
    seen, pool = set(), []
    cw_key = tuple(tuple(sorted(r)) for r in cw_routes)
    seen.add(cw_key)
    pool.append([list(r) for r in cw_routes])
    for s in ss.samples():
        cl = tuple(tuple(sorted(c)) for c in
                   qubo.decode_assignment(dict(s), ma))
        if cl not in seen:
            seen.add(cl)
            pool.append([list(c) for c in cl])
        if len(pool) >= TOPK:
            break

    total_sample_t, max_bqm = t_a, bqm_a.num_variables
    tsp_cache = {}

    def route_cluster(cl):
        key = tuple(sorted(cl))
        if key in tsp_cache:
            return tsp_cache[key]
        nonlocal total_sample_t, max_bqm
        conf = {(i, j) for (i, j) in conflicts if i in cl and j in cl}
        bqm_t, mt = qubo.tsp_bqm(list(cl), co.tau, encoding="domainwall",
                                 conflicts=conf)
        max_bqm = max(max_bqm, bqm_t.num_variables)
        ss_t, t = sample_bqm(bqm_t, num_reads=READS, sweeps=SWEEPS,
                             seed=seed)
        total_sample_t += t
        best = (False, float("inf"), sorted(cl, key=lambda c: E[c]))
        for s in ss_t.samples():
            order = qubo.decode_tsp(dict(s), mt)
            if order is None:
                continue
            r = evaluate(inst, inflate([order], co))
            ok = r["tw_viol"] == 0 and r["cap_viol"] == 0
            if (ok, -r["distance"]) > (best[0], -best[1]):
                best = (ok, r["distance"], order)
        tsp_cache[key] = best[2]
        return best[2]

    best_res, best_key, best_src = None, (False, float("-inf")), None
    for pi, clusters in enumerate(pool):
        routes_super = [route_cluster(cl) for cl in clusters if cl]
        res = evaluate(inst, inflate(routes_super, co))
        ok = res["tw_viol"] == 0 and res["cap_viol"] == 0
        key = (ok, -res["distance"])
        if key > best_key:
            best_key, best_res = key, res
            best_src = "warmstart" if pi == 0 else "qubo-sampled"

    # classical reference: savings on the uncoarsened instance
    v = as_view(inst)
    ref = evaluate(inst, inflate(savings(v), v))

    return {
        "instance": inst.name, "coarse_nodes": m,
        "assign_vars": bqm_a.num_variables, "max_bqm": max_bqm,
        "fqs_vars_equiv": M * inst.n_customers ** 2,
        "dist": best_res["distance"], "veh": best_res["vehicles"],
        "tw_viol": best_res["tw_viol"], "cap_viol": best_res["cap_viol"],
        "sample_t_s": round(total_sample_t, 1),
        "total_t_s": round(time.time() - t0, 1),
        "savings_dist": ref["distance"], "savings_veh": ref["vehicles"],
        "best_from": best_src,
    }


def main():
    files = sys.argv[1:] or ["C101.csv", "R101.csv", "RC101.csv",
                             "C201.csv"]
    rows = []
    hdr = (f"{'instance':<10} {'m':>4} {'maxBQM':>7} {'FQSequiv':>9} "
           f"{'dist':>8} {'veh':>4} {'TW':>3} {'cap':>4} "
           f"{'t_smp':>6} {'sav_dist':>9} {'sav_veh':>8}")
    print(hdr)
    print("-" * len(hdr))
    for path in files:
        r = run_instance(path)
        print(f"{r['instance']:<10} {r['coarse_nodes']:>4} "
              f"{r['max_bqm']:>7} {r['fqs_vars_equiv']:>9} "
              f"{r['dist']:>8} {r['veh']:>4} {r['tw_viol']:>3} "
              f"{r['cap_viol']:>4} {r['sample_t_s']:>6} "
              f"{r['savings_dist']:>9} {r['savings_veh']:>8}  {r['best_from']}")
        rows.append(r)
    with open("results_expB.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print("\nwrote results_expB.csv")


if __name__ == "__main__":
    main()
