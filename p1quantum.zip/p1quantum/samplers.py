"""Sampler layer.

Default backend: dwave.samplers.SimulatedAnnealingSampler — D-Wave's
production classical annealer implementation (the standard control in the
quantum-annealing literature, including papers 1-3's lineage).

QPU / Leap hybrid backends are wired in run_qpu.py; they need only a Leap
API token and `pip install dwave-system`.
"""
from __future__ import annotations

import time

from dwave.samplers import (SimulatedAnnealingSampler, SteepestDescentSampler,
                            TabuSampler)

_SAMPLERS = {
    "sa": SimulatedAnnealingSampler(),
    "tabu": TabuSampler(),
    "steepest": SteepestDescentSampler(),
}


def sample_bqm(bqm, backend: str = "sa", num_reads: int = 500,
               sweeps: int = 1000, seed: int = None):
    t0 = time.time()
    if backend == "sa":
        ss = _SAMPLERS["sa"].sample(bqm, num_reads=num_reads,
                                    num_sweeps=sweeps, seed=seed)
    elif backend == "tabu":
        ss = _SAMPLERS["tabu"].sample(bqm, num_reads=num_reads)
    elif backend == "steepest":
        ss = _SAMPLERS["steepest"].sample(bqm, num_reads=num_reads)
    else:
        raise ValueError(backend)
    return ss, time.time() - t0


def feasible_fraction(ss, decoder, meta) -> float:
    """Fraction of returned samples that decode to a VALID structure --
    the sample-level feasibility metric used in the annealing literature."""
    ok = 0
    for s in ss.samples():
        if decoder(dict(s), meta) is not None:
            ok += 1
    return ok / len(ss)
