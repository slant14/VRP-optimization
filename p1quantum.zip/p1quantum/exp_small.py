"""Experiment A -- head-to-head at annealer scale (N = 5, 10).

These are the sizes at which paper 3 ran its D-Wave experiments across the
Solomon suite, i.e. the sizes where the FQS formulation (paper 1) still
fits. We compare, per truncated instance:

  FQS (paper 1)            : monolithic x_{v,j,k} BQM
  DECOMP-OH (this work)    : assignment BQM + per-cluster one-hot TSP BQMs
  DECOMP-DW (this work)    : assignment BQM + per-cluster domain-wall TSP
                             BQMs with TW conflict-pair penalties

Sampler: dwave.samplers.SimulatedAnnealingSampler, identical budget
(num_reads, sweeps) for every method. Metrics:
  vars        -- total binary variables (max single BQM in parentheses)
  valid%      -- fraction of samples decoding to a structurally valid
                 solution (the standard annealing feasibility metric)
  best_dist   -- best decoded solution's distance on the ORIGINAL truncated
                 instance (TW/cap-feasible solutions only; inf if none)
  t_s         -- total sampling wall time

Writes results to results_expA.csv.
"""
from __future__ import annotations

import csv
import sys

import numpy as np

import qubo
from coarsen import evaluate
from instances import parse_solomon_csv
from samplers import feasible_fraction, sample_bqm

READS, SWEEPS = 500, 2000


def truncate(inst, N, M):
    from instances import Instance
    keep = list(range(N + 1))
    return Instance(f"{inst.name}-N{N}", M, inst.capacity,
                    inst.xy[keep], inst.demand[keep], inst.ready[keep],
                    inst.due[keep], inst.service[keep])


def route_metrics(inst, routes):
    r = evaluate(inst, routes)
    ok = r["tw_viol"] == 0 and r["cap_viol"] == 0
    return r["distance"], ok


def run_fqs(inst, seed):
    bqm, meta = qubo.fqs_bqm(inst.dist, inst.n_vehicles)
    ss, t = sample_bqm(bqm, num_reads=READS, sweeps=SWEEPS, seed=seed)
    valid = feasible_fraction(ss, qubo.decode_fqs, meta)
    best, bd = None, float("inf")
    for s in ss.samples():
        routes = qubo.decode_fqs(dict(s), meta)
        if routes is None:
            continue
        d, ok = route_metrics(inst, routes)
        if ok and d < bd:
            bd, best = d, routes
    return {"vars": bqm.num_variables, "max_bqm": bqm.num_variables,
            "valid": valid, "best_dist": bd, "t_s": t}


def run_decomp(inst, seed, encoding, topk=10):
    E = inst.ready
    L = inst.due
    S = inst.service
    mid = (E + L) / 2
    D = 0.5 * inst.dist + 0.5 * np.abs(mid[:, None] - mid[None, :]) \
        * (inst.dist.max() / max(inst.due[0], 1))
    conflicts = qubo.tw_conflicts(list(range(1, inst.n_customers + 1)),
                                  E, L, S, inst.dist)
    mutual = {(i, j) for (i, j) in conflicts if (j, i) in conflicts}
    bqm_a, ma = qubo.assignment_bqm(D, inst.dist[0], inst.demand,
                                    inst.n_vehicles, inst.capacity,
                                    mutual_conflicts=mutual)
    total_t, total_vars, max_bqm = 0.0, bqm_a.num_variables, \
        bqm_a.num_variables
    ss, t = sample_bqm(bqm_a, num_reads=READS, sweeps=SWEEPS, seed=seed)
    total_t += t
    valid_a = feasible_fraction(
        ss, lambda s, m: (qubo.decode_assignment(s, m)
                          if sum(s.values()) == m["N"] else None), ma)
    # top-K DISTINCT assignments from the sample pool (annealing-idiomatic:
    # use the distribution, not just the argmin)
    seen, pool = set(), []
    for s in ss.samples():
        cl = tuple(tuple(sorted(c)) for c in
                   qubo.decode_assignment(dict(s), ma))
        if cl not in seen:
            seen.add(cl)
            pool.append([list(c) for c in cl])
        if len(pool) >= topk:
            break

    tsp_cache = {}

    def route_cluster(cl):
        key = tuple(sorted(cl))
        if key in tsp_cache:
            return tsp_cache[key]
        conf = {(i, j) for (i, j) in conflicts if i in cl and j in cl}
        bqm_t, mt = qubo.tsp_bqm(list(cl), inst.dist, encoding=encoding,
                                 conflicts=conf)
        nonlocal total_t, total_vars, max_bqm
        total_vars += bqm_t.num_variables
        max_bqm = max(max_bqm, bqm_t.num_variables)
        ss_t, t = sample_bqm(bqm_t, num_reads=READS, sweeps=SWEEPS,
                             seed=seed)
        total_t += t
        vfrac = feasible_fraction(ss_t, qubo.decode_tsp, mt)
        best = (False, float("inf"), sorted(cl, key=lambda c: E[c]))
        for s in ss_t.samples():
            order = qubo.decode_tsp(dict(s), mt)
            if order is None:
                continue
            d, ok = route_metrics(inst, [order])
            cand = (ok, d, order)
            # prefer feasible, then shorter
            if (cand[0], -cand[1]) > (best[0], -best[1]):
                best = cand
        tsp_cache[key] = (best[2], vfrac)
        return tsp_cache[key]

    best_d, best_ok, valid_ts = float("inf"), False, []
    for clusters in pool:
        routes = []
        for cl in clusters:
            if not cl:
                continue
            order, vfrac = route_cluster(cl)
            valid_ts.append(vfrac)
            routes.append(order)
        d, ok = route_metrics(inst, routes)
        if (ok, -d) > (best_ok, -best_d):
            best_ok, best_d = ok, d
    return {"vars": total_vars, "max_bqm": max_bqm,
            "valid": float(np.mean([valid_a] + valid_ts)),
            "best_dist": best_d if best_ok else float("inf"),
            "t_s": total_t}


def brute_force_opt(inst):
    """Exact optimum for tiny N (<= 6): all partitions of customers into up
    to M ordered routes, TW/cap checked. Returns inf if infeasible."""
    import itertools
    N, M = inst.n_customers, inst.n_vehicles
    cust = list(range(1, N + 1))
    best = float("inf")

    def rec(remaining, routes_done, dist_acc):
        nonlocal best
        if dist_acc >= best:
            return
        if not remaining:
            best = dist_acc
            return
        if len(routes_done) == M:
            return
        first = remaining[0]
        rest = remaining[1:]
        for k in range(len(rest) + 1):
            for extra in itertools.combinations(rest, k):
                group = [first] + list(extra)
                left = [c for c in rest if c not in extra]
                for perm in itertools.permutations(group):
                    d, ok = route_metrics(inst, [list(perm)])
                    if ok:
                        rec(left, routes_done + [list(perm)], dist_acc + d)

    rec(cust, [], 0.0)
    return best


def main():
    files = sys.argv[1:] or ["C101.csv", "R101.csv", "RC101.csv"]
    rows = []
    hdr = (f"{'inst':<12} {'N':>3} {'method':<10} {'vars':>6} "
           f"{'maxBQM':>7} {'valid%':>7} {'best_dist':>10} {'t_s':>6}")
    print(hdr)
    print("-" * len(hdr))
    for path in files:
        full = parse_solomon_csv(path)
        for N in (5, 10):
            # fleet size: what a TW-aware greedy needs (guarantees the
            # instance is feasible for all methods)
            probe = truncate(full, N, 25)
            from coarsen import as_view, inflate
            from solvers import greedy as _greedy
            v = as_view(probe)
            M = evaluate(probe, inflate(_greedy(v), v))["vehicles"]
            inst = truncate(full, N, M)
            if N <= 6:
                opt = brute_force_opt(inst)
                o = "inf" if opt == float("inf") else f"{opt:.1f}"
                print(f"{inst.name:<12} {N:>3} {'EXACT-OPT':<10} "
                      f"{'-':>6} {'-':>7} {'-':>7} {o:>10} {'-':>6}")
                rows.append([inst.name, N, "EXACT-OPT", "-", "-", "-", o,
                             "-"])
            for method, fn in (
                ("FQS", lambda i, s: run_fqs(i, s)),
                ("DECOMP-OH", lambda i, s: run_decomp(i, s, "onehot")),
                ("DECOMP-DW", lambda i, s: run_decomp(i, s, "domainwall")),
            ):
                r = fn(inst, 42)
                bd = ("inf" if r["best_dist"] == float("inf")
                      else f"{r['best_dist']:.1f}")
                print(f"{inst.name:<12} {N:>3} {method:<10} "
                      f"{r['vars']:>6} {r['max_bqm']:>7} "
                      f"{100 * r['valid']:>6.1f} {bd:>10} "
                      f"{r['t_s']:>6.1f}")
                rows.append([inst.name, N, method, r["vars"], r["max_bqm"],
                             round(100 * r["valid"], 1), bd,
                             round(r["t_s"], 1)])
    with open("results_expA.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["instance", "N", "method", "vars", "max_bqm",
                    "valid_pct", "best_dist", "t_s"])
        w.writerows(rows)
    print("\nwrote results_expA.csv")


if __name__ == "__main__":
    main()
